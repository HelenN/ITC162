//itc-162, spring 2017, homework assignment 3

package com.murach.tempconverter;

import android.os.Bundle;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


public class TempConverterActivity extends Activity implements OnEditorActionListener{

	//declare variables for EditText and TextView widgets
	private EditText fahrenheitEditText;
	private TextView celciusTextView;

	//define instance variable for fahrenheit temperature
	private String fahrenheitString = "";
	private String celciusString = "";

	//define SharedPreferences object
	private SharedPreferences savedValues;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_temp_converter);

		//get references to the EditText and TextView widgets
		fahrenheitEditText = (EditText) findViewById(R.id.fahrenheitEditText);
		celciusTextView = (TextView) findViewById(R.id.celciusTextView);

		//set the listener
		fahrenheitEditText.setOnEditorActionListener(this);

		//get SharedPreferences object
		savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);

	}

	@Override
	public void onPause() {

		//save the instance variables
		Editor editor = savedValues.edit();
		editor.putString("fahrenheitString", fahrenheitString);
		editor.putString("celciusString", celciusString);
		editor.commit();

		super.onPause();

	}

	@Override
	public void onResume() {

		super.onResume();

		//get the instance variables
		fahrenheitString = savedValues.getString("fahrenheitString", "");
		celciusString = savedValues.getString("celciusString", "");

		//set the fahrenheit and celcius temperatures from previous state
		fahrenheitEditText.setText(fahrenheitString);
		celciusTextView.setText(celciusString);

	}

	//method to convert fahrenheit temperature to celsius temperature
	public void calculateAndDisplay() {

		//get the fahrenheit temperature
		fahrenheitString = fahrenheitEditText.getText().toString();
		int fahrenheitTemp = Integer.parseInt(fahrenheitString);

		//calculate celsius temperature
		int celciusTemp = (fahrenheitTemp - 32) * 5 / 9;

		//display the celsius temperature after calculation
		celciusString = Integer.toString(celciusTemp);
		celciusTextView.setText(celciusString);
	}

	//implement the listener
	@Override
	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

		if (actionId == EditorInfo.IME_ACTION_DONE ||
				actionId == EditorInfo.IME_ACTION_UNSPECIFIED)
		{

			calculateAndDisplay();
		}
		return false;
	}
}