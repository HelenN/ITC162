package com.nhan.tictactoe;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;


public class TicTacToe extends AppCompatActivity implements OnClickListener {

    //instance variables for the widgets
    private Button gameGrid[][] = new Button[3][3];
    private TextView gameStatusTextView;
    private Button newGameButton;

    //instance variables for widget text and functions
    private String gameButton00Text = "";
    private String gameButton01Text = "";
    private String gameButton02Text = "";
    private String gameButton10Text = "";
    private String gameButton11Text = "";
    private String gameButton12Text = "";
    private String gameButton20Text = "";
    private String gameButton21Text = "";
    private String gameButton22Text = "";
    private String gameStatusTextViewLabel = "Player X's turn";
    private String player = "X";

    //define SharedPreferences object
    private SharedPreferences savedValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        //get references to widgets
        gameGrid[0][0] = (Button) findViewById(R.id.gameButton00);
        gameGrid[0][1] = (Button) findViewById(R.id.gameButton01);
        gameGrid[0][2] = (Button) findViewById(R.id.gameButton02);
        gameGrid[1][0] = (Button) findViewById(R.id.gameButton10);
        gameGrid[1][1] = (Button) findViewById(R.id.gameButton11);
        gameGrid[1][2] = (Button) findViewById(R.id.gameButton12);
        gameGrid[2][0] = (Button) findViewById(R.id.gameButton20);
        gameGrid[2][1] = (Button) findViewById(R.id.gameButton21);
        gameGrid[2][2] = (Button) findViewById(R.id.gameButton22);
        gameStatusTextView = (TextView) findViewById(R.id.gameStatusTextView);
        newGameButton = (Button) findViewById(R.id.newGameButton);

        //set listeners for widgets
        gameGrid[0][0].setOnClickListener(this);
        gameGrid[0][1].setOnClickListener(this);
        gameGrid[0][2].setOnClickListener(this);
        gameGrid[1][0].setOnClickListener(this);
        gameGrid[1][1].setOnClickListener(this);
        gameGrid[1][2].setOnClickListener(this);
        gameGrid[2][0].setOnClickListener(this);
        gameGrid[2][1].setOnClickListener(this);
        gameGrid[2][2].setOnClickListener(this);
        newGameButton.setOnClickListener(this);

        //get SharedPreferences object
        savedValues = getSharedPreferences("SavedValues", MODE_PRIVATE);
    }

    @Override
    public void onPause() {
        //save the instance variables
        Editor editor = savedValues.edit();
        editor.putString("gameButton00Text", gameGrid[0][0].getText().toString());
        editor.putString("gameButton01Text", gameGrid[0][1].getText().toString());
        editor.putString("gameButton02Text", gameGrid[0][2].getText().toString());
        editor.putString("gameButton10Text", gameGrid[1][0].getText().toString());
        editor.putString("gameButton11Text", gameGrid[1][1].getText().toString());
        editor.putString("gameButton12Text", gameGrid[1][2].getText().toString());
        editor.putString("gameButton20Text", gameGrid[2][0].getText().toString());
        editor.putString("gameButton21Text", gameGrid[2][1].getText().toString());
        editor.putString("gameButton22Text", gameGrid[2][2].getText().toString());
        editor.putString("gameStatusTextViewLabel", gameStatusTextViewLabel);
        editor.putString("player", player);

        editor.commit();

        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();

        //get the instance variables
        gameButton00Text = savedValues.getString("gameButton00Text", "");
        gameButton01Text = savedValues.getString("gameButton01Text", "");
        gameButton02Text = savedValues.getString("gameButton02Text", "");
        gameButton10Text = savedValues.getString("gameButton10Text", "");
        gameButton11Text = savedValues.getString("gameButton11Text", "");
        gameButton12Text = savedValues.getString("gameButton12Text", "");
        gameButton20Text = savedValues.getString("gameButton20Text", "");
        gameButton21Text = savedValues.getString("gameButton21Text", "");
        gameButton22Text = savedValues.getString("gameButton22Text", "");
        gameStatusTextViewLabel = savedValues.getString("gameStatusTextViewLabel",
                "Player X's turn");
        player = savedValues.getString("player", "X");

        //set the game grid squares' labels
        gameGrid[0][0].setText(gameButton00Text);
        gameGrid[0][1].setText(gameButton01Text);
        gameGrid[0][2].setText(gameButton02Text);
        gameGrid[1][0].setText(gameButton10Text);
        gameGrid[1][1].setText(gameButton11Text);
        gameGrid[1][2].setText(gameButton12Text);
        gameGrid[2][0].setText(gameButton20Text);
        gameGrid[2][1].setText(gameButton21Text);
        gameGrid[2][2].setText(gameButton22Text);

        //set the game status text
        gameStatusTextView.setText(gameStatusTextViewLabel);
    }

    //clears the game grid by resetting all squares to ""
    public void clearGrid() {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++)
                gameGrid[r][c].setText("");
        }
    }

    //starts a new game
    public void startNewGame() {
        clearGrid();
        player = "X";
        gameStatusTextViewLabel = "Player X's turn";
        gameStatusTextView.setText(gameStatusTextViewLabel);

    }

    //determines if game can be continued (there are available spaces on game grid to click)
    public boolean continueGame() {
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 3; c++)
                if (gameGrid[r][c].getText() == "") return true;
        return false;
    }

    //checks if game has been won, drawn, or can be continued (and updates game status)
    private void checkForGameOver() {
        //check for win by row
        if (gameGrid[0][0].getText() == gameGrid[0][1].getText()
                && gameGrid[0][1].getText() == gameGrid[0][2].getText()
                && gameGrid[0][2].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][0].getText() + " wins!";
        }
        else if (gameGrid[1][0].getText() == gameGrid[1][1].getText()
                && gameGrid[1][1].getText() == gameGrid[1][2].getText()
                && gameGrid[1][2].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[1][0].getText() + " wins!";
        }
        else if (gameGrid[2][0].getText() == gameGrid[2][1].getText()
                && gameGrid[2][1].getText() == gameGrid[2][2].getText()
                && gameGrid[2][2].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[2][0].getText() + " wins!";
        }

        //check for win by column
        else if (gameGrid[0][0].getText() == gameGrid[1][0].getText()
                && gameGrid[1][0].getText() == gameGrid[2][0].getText()
                && gameGrid[2][0].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][0].getText() + " wins!";
        }
        else if (gameGrid[0][1].getText() == gameGrid[1][1].getText()
                && gameGrid[1][1].getText() == gameGrid[2][1].getText()
                && gameGrid[2][1].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][1].getText() + " wins!";
        }
        else if (gameGrid[0][2].getText() == gameGrid[1][2].getText()
                && gameGrid[1][2].getText() == gameGrid[2][2].getText()
                && gameGrid[2][2].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][2].getText() + " wins!";
        }

        //check for win by diagonal
        else if (gameGrid[0][0].getText() == gameGrid[1][1].getText()
                && gameGrid[1][1].getText() == gameGrid[2][2].getText()
                && gameGrid[2][2].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][2].getText() + " wins!";
        }
        else if (gameGrid[0][2].getText() == gameGrid[1][1].getText()
                && gameGrid[1][1].getText() == gameGrid[2][0].getText()
                && gameGrid[2][0].getText() != "")
        {
            gameStatusTextViewLabel = "Player " + gameGrid[0][2].getText() + " wins!";
        }

        //check for draw (game cannot be continued and no win conditions are met)
        else if (continueGame() == false) {
            gameStatusTextViewLabel = "It's a draw!";

        }

        //game is not over, next player's turn
        else {
            //update next player's turn
            if (player == "X") player = "O";
            else player = "X";
            gameStatusTextViewLabel = "Player " + player + "'s turn";
        }

        //update game status text
        gameStatusTextView.setText(gameStatusTextViewLabel);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.gameButton00:
                if (gameGrid[0][0].getText() == "") {
                    gameGrid[0][0].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton01:
                if (gameGrid[0][1].getText() == "") {
                    gameGrid[0][1].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton02:
                if (gameGrid[0][2].getText() == "") {
                    gameGrid[0][2].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton10:
                if (gameGrid[1][0].getText() == "") {
                    gameGrid[1][0].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton11:
                if (gameGrid[1][1].getText() == "") {
                    gameGrid[1][1].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton12:
                if (gameGrid[1][2].getText() == "") {
                    gameGrid[1][2].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton20:
                if (gameGrid[2][0].getText() == "") {
                    gameGrid[2][0].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton21:
                if (gameGrid[2][1].getText() == "") {
                    gameGrid[2][1].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.gameButton22:
                if (gameGrid[2][2].getText() == "") {
                    gameGrid[2][2].setText(player);
                    checkForGameOver();
                }
                break;
            case R.id.newGameButton:
                startNewGame();
                break;
        }
    }



}
